from django import forms
#from django.forms import ModelForm
from .models import TODO,MyCustomModel
from django.contrib.auth import authenticate,password_validation
from django.contrib.auth.forms import UserCreationForm,SetPasswordForm
from django.core.exceptions import ValidationError





class TODOForm(forms.ModelForm):
    class Meta:
        model = TODO
        fields = ['tasks' , 'status' ,'image', 'priority']

class signupForm(UserCreationForm):
    #email = forms.EmailField()
    class Meta:
        model = MyCustomModel
        fields = ("email","username")

class forget_passwordForm(forms.ModelForm):
    email = forms.EmailField(max_length=125)
    class Meta:
        model = MyCustomModel
        fields = ["email",]

class Password_rest_form(forms.Form):
    new_password = forms.CharField(max_length=100, widget = forms.PasswordInput)
    confirm_password = forms.CharField(max_length=100, widget = forms.PasswordInput)
    
       



# class PasswordUpdateForm(signupForm):
#     class Meta:
#         models = MyCustomModel
#         fields = ('password',)






# class forget_pass_form(SetPasswordForm):
#     field_order = [ "new_password1", "new_password2"]



    
# class LoginForm(forms.ModelForm):
#     """
#       Form for Logging in  users
#     """
#     password  = forms.CharField(label= 'Password', widget=forms.PasswordInput)
    

#     class Meta:
#         model  =  MyCustomModel
#         fields =  ('email', 'password',)


#         def clean(self):
#             if self.is_valid():

#                 email = self.cleaned_data.get('email')
#                 password = self.cleaned_data.get('password')
#                 if not authenticate(email=email, password=password):
#                     raise forms.ValidationError('Invalid Login')


    


# class MytodoItemCreateForm(forms.ModelForm):
    
#      class Meta:
#          model = todo_list
#          fields = ('tasks', 'action' )
         


# class MytodoItemUpdateForm(forms.ModelForm):

# #     class Meta:
# #         model = MyCustomModel
# #         fields = ('name',)

