# from django.contrib.auth.tokens import PasswordResetTokenGenerator
# import six

# class TokenGenerator(PasswordResetTokenGenerator):
#     def _make_hash_value(self, user, timestamp):
#         return (
#             six.text_type(user.pk)+ six.text_type(timestamp) +six.text_type(user.is_active)
#         )

# account_activation_token = TokenGenerator()


# token_idb64
# This method must return a base64 encoded data, it's used to validate the token, and can embed data. It must not embed critical data, it can be simply decoded.

# _make_hash_value
# This is the hash value, it must be unique by user. It will be used to generate the token, and to validate a token with idb64 content.
