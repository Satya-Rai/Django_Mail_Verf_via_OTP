from django.conf import settings
from django.core.mail import send_mail



def send_otp(email, otp):
    try:
        subject = 'Your account needs to be vrified'
        message = f'{otp}'
        email_from = settings.EMAI_HOST_USER
        recipient_list = [email,]
        send_mail(subject,message, email_from, recipient_list )

    except Exception as e:
        return False 
    
    return True